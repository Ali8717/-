    let categories = JSON.parse(localStorage.getItem('awlad_issa_categories')) || [
      { id: '1', name: 'بقالة ومواد غذائية', icon: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&q=80' },
      { id: '2', name: 'ألبان وأجبان', icon: 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=200&q=80' },
      { id: '3', name: 'خضار وفواكه', icon: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=200&q=80' },
      { id: '4', name: 'مشروبات وعصائر', icon: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=200&q=80' },
      { id: '5', name: 'تسالي وشوكولاتة', icon: 'https://images.unsplash.com/photo-1581798459219-318e76aecc7b?w=200&q=80' },
      { id: '6', name: 'منظفات منزلية', icon: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=200&q=80' }
    ];

    let products = JSON.parse(localStorage.getItem('awlad_issa_products')) || [];
    let cart = JSON.parse(localStorage.getItem('awlad_issa_cart')) || [];
    let incomingOrders = JSON.parse(localStorage.getItem('awlad_issa_orders')) || [];

    let registeredUsers = JSON.parse(localStorage.getItem('awlad_issa_real_users')) || [];
    let mainAdmin = registeredUsers.find(u => u.username === 'ali70');
    if (!mainAdmin) {
      mainAdmin = { username: 'ali70', pass: '70481570', role: 'admin' };
      registeredUsers.unshift(mainAdmin);
    } else {
      mainAdmin.role = 'admin';
      mainAdmin.pass = '70481570';
    }
    localStorage.setItem('awlad_issa_real_users', JSON.stringify(registeredUsers));

    let currentUser = JSON.parse(localStorage.getItem('awlad_issa_session')) || null;
    let activeProduct = null;
    let modalSelectedQty = 1;
    let activeCategoryName = null;
    
    // متغيرات الكاميرا المحدثة للتشغيل التلقائي
    let html5QrCode = null;
    let pressTimer = null;
    let isOnlineSyncActive = true;

    // ================== إعداد Firebase والمزامنة الفورية ==================
    const firebaseConfig = {
      apiKey: "AIzaSyDMw3Eiv_-0wjBwHJ0XaMM4da32bG8BryM",
      authDomain: "awlad-issa-store.firebaseapp.com",
      projectId: "awlad-issa-store",
      storageBucket: "awlad-issa-store.firebasestorage.app",
      messagingSenderId: "238379866487",
      appId: "1:238379866487:web:1ae979c81cdc4dee4aa972",
      measurementId: "G-Z4DRY5RX8G"
    };
    firebase.initializeApp(firebaseConfig);
    const db = firebase.firestore();
    let firebaseSyncStarted = false;

    function initFirebaseSync() {
      if (firebaseSyncStarted) return;
      firebaseSyncStarted = true;

      // التأكد من وجود حساب المالك الأساسي على قاعدة البيانات دائماً
      db.collection('users').doc('ali70').set(mainAdmin, { merge: true }).catch(err => console.error('خطأ مزامنة المالك:', err));

      // مزامنة الفئات فورياً
      db.collection('categories').onSnapshot(snapshot => {
        categories = snapshot.docs.map(d => d.data());
        localStorage.setItem('awlad_issa_categories', JSON.stringify(categories));
        renderCategories();
        updateSyncState(true);
      }, err => { console.error('خطأ مزامنة الفئات:', err); updateSyncState(false); });

      // مزامنة المنتجات فورياً
      db.collection('products').onSnapshot(snapshot => {
        products = snapshot.docs.map(d => d.data());
        localStorage.setItem('awlad_issa_products', JSON.stringify(products));
        const q = document.getElementById('searchInput').value.trim();
        if (q) { searchProducts(); }
        else if (document.getElementById('productsView').style.display === 'block') {
          renderProductGrid(products.filter(p => p.category === document.getElementById('categoryTitle').innerText));
        }
        updateSyncState(true);
      }, err => { console.error('خطأ مزامنة المنتجات:', err); updateSyncState(false); });

      // مزامنة الطلبات الواردة فورياً
      db.collection('orders').onSnapshot(snapshot => {
        incomingOrders = snapshot.docs.map(d => d.data()).sort((a, b) => b.id - a.id);
        localStorage.setItem('awlad_issa_orders', JSON.stringify(incomingOrders));
        updateOrdersBadge();
        const ordersModal = document.getElementById('incomingOrdersModal');
        if (ordersModal && ordersModal.classList.contains('active')) renderOrdersList();
        updateSyncState(true);
      }, err => { console.error('خطأ مزامنة الطلبات:', err); updateSyncState(false); });

      // مزامنة حسابات المستخدمين فورياً
      db.collection('users').onSnapshot(snapshot => {
        if (snapshot.empty) return;
        registeredUsers = snapshot.docs.map(d => d.data());
        localStorage.setItem('awlad_issa_real_users', JSON.stringify(registeredUsers));
        if (currentUser) {
          const updatedSelf = registeredUsers.find(u => u.username === currentUser.username);
          if (updatedSelf) {
            currentUser = updatedSelf;
            localStorage.setItem('awlad_issa_session', JSON.stringify(currentUser));
            setupUserSession();
          }
        }
        const usersModal = document.getElementById('adminManagementModal');
        if (usersModal && usersModal.classList.contains('active')) loadUsersList();
        updateSyncState(true);
      }, err => { console.error('خطأ مزامنة المستخدمين:', err); updateSyncState(false); });

      seedFirestoreIfEmpty();
    }

    // رفع البيانات المحلية الموجودة إلى Firestore أول مرة فقط إذا كانت قاعدة البيانات فارغة
    async function seedFirestoreIfEmpty() {
      try {
        const catSnap = await db.collection('categories').limit(1).get();
        if (catSnap.empty && categories.length > 0) {
          const batch = db.batch();
          categories.forEach(cat => batch.set(db.collection('categories').doc(String(cat.id)), cat));
          await batch.commit();
        }
        const prodSnap = await db.collection('products').limit(1).get();
        if (prodSnap.empty && products.length > 0) {
          const batch = db.batch();
          products.forEach(p => batch.set(db.collection('products').doc(String(p.id)), p));
          await batch.commit();
        }
      } catch (err) {
        console.error('خطأ في الرفع الأولي للبيانات:', err);
      }
    }

    function initApp() {
      loadSavedCustomizations();
      if (!currentUser) {
        document.getElementById('authOverlay').style.display = 'flex';
      } else {
        const updatedSelf = registeredUsers.find(u => u.username === currentUser.username);
        if (updatedSelf) currentUser = updatedSelf;
        document.getElementById('authOverlay').style.display = 'none';
        setupUserSession();
      }
      renderCategories();
      updateCartBadge();
      updateOrdersBadge();
      checkNetworkSyncStatus();
      initFirebaseSync();

      window.addEventListener('online', () => { checkNetworkSyncStatus(); });
      window.addEventListener('offline', () => updateSyncState(false));
    }

    function toggleThemeMode() {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      if (currentTheme === 'dark') {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('awlad_issa_theme', 'light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('awlad_issa_theme', 'dark');
      }
    }

    function loadSavedCustomizations() {
      const savedTheme = localStorage.getItem('awlad_issa_theme');
      if (savedTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
      }
    }

    function checkNetworkSyncStatus() {
      if (navigator.onLine) {
        updateSyncState(true);
      } else {
        updateSyncState(false);
      }
    }

    function updateSyncState(isActive) {
      isOnlineSyncActive = isActive;
      const badge = document.getElementById('syncStatusBadge');
      const desc = document.getElementById('syncDescText');
      const spinner = document.getElementById('syncSpinner');
      if (badge && desc && spinner) {
        if (isActive) {
          badge.innerText = "نشطة";
          badge.style.background = "#dcfce7";
          badge.style.color = "#16a34a";
          desc.innerText = "البيانات متزامنة فورياً عبر الإنترنت.";
          spinner.style.animation = "spin 2s linear infinite";
        } else {
          badge.innerText = "متوقفة (غير متصل)";
          badge.style.background = "#fee2e2";
          badge.style.color = "#ef4444";
          desc.innerText = "أنت تعمل حالياً بدون إنترنت، ستتم المزامنة عند إعادة الاتصال.";
          spinner.style.animation = "none";
        }
      }
    }

    function triggerManualSync() {
      const spinner = document.getElementById('syncSpinner');
      if (spinner) spinner.style.transform = "rotate(360deg)";
      setTimeout(() => {
        checkNetworkSyncStatus();
        alert("تم فحص وتحديث المزامنة بنجاح!");
      }, 800);
    }

    function switchAuthMode(mode) {
      if (mode === 'login') {
        document.getElementById('tabLogin').classList.add('active');
        document.getElementById('tabRegister').classList.remove('active');
        document.getElementById('formLogin').style.display = 'block';
        document.getElementById('formRegister').style.display = 'none';
      } else {
        document.getElementById('tabRegister').classList.add('active');
        document.getElementById('tabLogin').classList.remove('active');
        document.getElementById('formRegister').style.display = 'block';
        document.getElementById('formLogin').style.display = 'none';
      }
    }

    function handleAuthLogin() {
      const u = document.getElementById('authUser').value.trim();
      const p = document.getElementById('authPass').value.trim();
      const found = registeredUsers.find(user => user.username === u && user.pass === p);
      if (found) {
        currentUser = found;
        localStorage.setItem('awlad_issa_session', JSON.stringify(currentUser));
        document.getElementById('authOverlay').style.display = 'none';
        setupUserSession();
      } else { alert("اسم المستخدم أو كلمة السر غير صحيحة!"); }
    }

    function handleAuthRegister() {
      const u = document.getElementById('regUser').value.trim();
      const p = document.getElementById('regPass').value.trim();
      if (!u || !p) { alert("يرجى ملء كافة البيانات!"); return; }
      if (registeredUsers.some(user => user.username === u)) { alert("اسم المستخدم موجود بالفعل!"); return; }
      const newUser = { username: u, pass: p, role: 'user' };
      registeredUsers.push(newUser);
      localStorage.setItem('awlad_issa_real_users', JSON.stringify(registeredUsers));
      db.collection('users').doc(newUser.username).set(newUser).catch(err => console.error('خطأ مزامنة الحساب:', err));
      currentUser = newUser;
      localStorage.setItem('awlad_issa_session', JSON.stringify(currentUser));
      document.getElementById('authOverlay').style.display = 'none';
      setupUserSession();
      alert("تم إنشاء حسابك بنجاح!");
    }

    function setupUserSession() {
      document.getElementById('currentUserDisplay').innerText = currentUser.username;
      const adminElements = document.querySelectorAll('.admin-only');
      adminElements.forEach(el => { el.style.display = currentUser.role === 'admin' ? 'block' : 'none'; });
    }

    function logout() {
      localStorage.removeItem('awlad_issa_session');
      currentUser = null;
      location.reload();
    }

    function openOnlineOrderCheckout() {
      if (cart.length === 0) {
        alert("سلة التسوق فارغة! أضف منتجات أولاً.");
        showHome();
        return;
      }
      closeModal('cartModal');
      openModal('onlineOrderModal');
    }

    function submitOnlineOrder() {
      const address = document.getElementById('orderAddress').value.trim();
      const phone = document.getElementById('orderPhone').value.trim();

      if (!address || !phone) {
        alert("يرجى إدخال العنوان ورقم التواصل!");
        return;
      }

      let grandTotal = cart.reduce((sum, item) => sum + (Number(item.price) * item.qty), 0);
      
      const newOrder = {
        id: Date.now(),
        client: currentUser.username,
        address: address,
        phone: phone,
        items: [...cart],
        total: grandTotal.toFixed(2),
        time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
      };

      incomingOrders.unshift(newOrder);
      localStorage.setItem('awlad_issa_orders', JSON.stringify(incomingOrders));
      db.collection('orders').doc(String(newOrder.id)).set(newOrder).catch(err => console.error('خطأ مزامنة الطلب:', err));
      updateOrdersBadge();

      alert(`تم إرسال طلبك الأونلاين بنجاح للأدمن!`);
      
      cart = [];
      localStorage.setItem('awlad_issa_cart', JSON.stringify(cart));
      updateCartBadge();
      closeModal('onlineOrderModal');
      showHome();
    }

    function updateOrdersBadge() {
      const badge = document.getElementById('ordersCountBadge');
      if (badge) badge.innerText = incomingOrders.length;
    }

    function renderOrdersList() {
      const container = document.getElementById('incomingOrdersContainer');
      container.innerHTML = '';
      if (incomingOrders.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-muted); padding:20px 0;">لا توجد طلبات واردة حالياً.</p>`;
        return;
      }

      incomingOrders.forEach((order, index) => {
        let itemsList = order.items.map(i => `${i.name} (×${i.qty})`).join('، ');
        container.innerHTML += `
          <div style="background:var(--bg); border:1px solid var(--card-border); border-radius:12px; padding:12px; margin-bottom:10px;">
            <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
              <b style="color:var(--primary); font-size:13px;">العميل: ${order.client}</b>
              <span style="font-size:11px; color:var(--text-muted);">${order.time}</span>
            </div>
            <p style="font-size:12px; margin-bottom:4px;"><b>العنوان:</b> ${order.address}</p>
            <p style="font-size:12px; margin-bottom:6px;"><b>الهاتف:</b> ${order.phone}</p>
            <p style="font-size:12px; margin-bottom:6px; color:var(--text-muted);"><b>المنتجات:</b> ${itemsList}</p>
            <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px dashed var(--card-border); padding-top:6px; margin-top:6px;">
              <b style="color:var(--primary); font-size:14px;">الإجمالي: ${order.total} ج.م</b>
              <button onclick="deleteOrder(${index})" style="background:#fee2e2; color:#ef4444; border:none; padding:4px 8px; border-radius:6px; font-size:11px; cursor:pointer;"><i class="fa-solid fa-check"></i> تم التسليم والحذف</button>
            </div>
          </div>
        `;
      });
    }

    function deleteOrder(index) {
      const deletedOrder = incomingOrders[index];
      incomingOrders.splice(index, 1);
      localStorage.setItem('awlad_issa_orders', JSON.stringify(incomingOrders));
      if (deletedOrder) db.collection('orders').doc(String(deletedOrder.id)).delete().catch(err => console.error('خطأ حذف الطلب:', err));
      updateOrdersBadge();
      renderOrdersList();
    }

    function renderCategories() {
      const catContainer = document.getElementById('categoriesContainer');
      const catSelect = document.getElementById('pCategory');
      catContainer.innerHTML = '';
      catSelect.innerHTML = '';

      categories.forEach(cat => {
        const card = document.createElement('div');
        card.className = 'category-card';
        card.innerHTML = `
          <div class="category-img-box"><img src="${cat.icon}"></div>
          <p>${cat.name}</p>
        `;
        card.onclick = () => openCategory(cat.name);
        card.onmousedown = () => startLongPress(cat);
        card.onttouchstart = () => startLongPress(cat);
        card.onmouseup = cancelLongPress;
        card.ontouchend = cancelLongPress;
        card.onmouseleave = cancelLongPress;

        catContainer.appendChild(card);
        catSelect.innerHTML += `<option value="${cat.name}">${cat.name}</option>`;
      });
    }

    function startLongPress(cat) {
      if (!currentUser || currentUser.role !== 'admin') return;
      pressTimer = setTimeout(() => {
        activeCategoryName = cat.name;
        document.getElementById('selectedCategoryTitleName').innerText = `إدارة فئة: ${cat.name}`;
        document.getElementById('newCategoryIconUrl').value = cat.icon;
        openModal('categoryActionsModal');
      }, 600);
    }
    function cancelLongPress() { if (pressTimer) clearTimeout(pressTimer); }

    function handleProductFileUpload(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) { document.getElementById('pImgUrl').value = e.target.result; };
        reader.readAsDataURL(file);
      }
    }
    function handleCategoryUpdateFileUpload(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) { document.getElementById('newCategoryIconUrl').value = e.target.result; };
        reader.readAsDataURL(file);
      }
    }

    function saveCategoryIconUpdate() {
      const newIcon = document.getElementById('newCategoryIconUrl').value.trim();
      if (!newIcon) return;
      const cat = categories.find(c => c.name === activeCategoryName);
      if (cat) {
        cat.icon = newIcon;
        localStorage.setItem('awlad_issa_categories', JSON.stringify(categories));
        db.collection('categories').doc(String(cat.id)).set(cat).catch(err => console.error('خطأ مزامنة الفئة:', err));
        renderCategories();
        closeModal('categoryActionsModal');
      }
    }
    function deleteCategory() {
      if (confirm(`حذف الفئة "${activeCategoryName}"؟`)) {
        const deletedCat = categories.find(c => c.name === activeCategoryName);
        const removedProducts = products.filter(p => p.category === activeCategoryName);

        categories = categories.filter(c => c.name !== activeCategoryName);
        localStorage.setItem('awlad_issa_categories', JSON.stringify(categories));
        products = products.filter(p => p.category !== activeCategoryName);
        localStorage.setItem('awlad_issa_products', JSON.stringify(products));

        const batch = db.batch();
        if (deletedCat) batch.delete(db.collection('categories').doc(String(deletedCat.id)));
        removedProducts.forEach(p => batch.delete(db.collection('products').doc(String(p.id))));
        batch.commit().catch(err => console.error('خطأ حذف الفئة:', err));

        renderCategories();
        closeModal('categoryActionsModal');
      }
    }
    function saveNewCategory() {
      const name = document.getElementById('newCatName').value.trim();
      const icon = document.getElementById('newCatIcon').value.trim() || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&q=80';
      if (!name) return;
      const newCat = { id: String(Date.now()), name, icon };
      categories.push(newCat);
      localStorage.setItem('awlad_issa_categories', JSON.stringify(categories));
      db.collection('categories').doc(newCat.id).set(newCat).catch(err => console.error('خطأ مزامنة الفئة:', err));
      renderCategories();
      closeModal('addCategoryModal');
    }

    function openCategory(catName) {
      document.getElementById('categoriesView').style.display = 'none';
      document.getElementById('productsView').style.display = 'block';
      document.getElementById('categoryTitle').innerText = catName;
      renderProductGrid(products.filter(p => p.category === catName));
    }

    function renderProductGrid(items) {
      const container = document.getElementById('productsContainer');
      container.innerHTML = '';
      if (items.length === 0) {
        container.innerHTML = `<p style="grid-column: 1/-1; text-align:center; color:var(--text-muted); padding:30px 0;">لا توجد منتجات.</p>`;
        return;
      }
      items.forEach(p => {
        container.innerHTML += `
          <div class="product-card" onclick="onProductClick(${p.id})">
            <div class="product-img-box"><img src="${p.image || 'https://via.placeholder.com/150'}"></div>
            <div class="product-title">${p.name}</div>
            <div class="product-price">${p.price} ج.م</div>
          </div>
        `;
      });
    }

    function onProductClick(id) {
      activeProduct = products.find(p => p.id === id);
      if (!activeProduct) return;
      modalSelectedQty = 1;
      document.getElementById('modalProductName').innerText = activeProduct.name;
      document.getElementById('modalProductPrice').innerText = `${activeProduct.price} ج.م`;
      document.getElementById('modalProductImg').src = activeProduct.image || 'https://via.placeholder.com/150';
      document.getElementById('modalProductQty').innerText = modalSelectedQty;
      document.getElementById('adminProductActions').style.display = (currentUser && currentUser.role === 'admin') ? 'block' : 'none';
      openModal('userProductModal');
    }

    function changeModalQty(amt) {
      modalSelectedQty += amt;
      if (modalSelectedQty < 1) modalSelectedQty = 1;
      document.getElementById('modalProductQty').innerText = modalSelectedQty;
    }

    function addToCartFromModal() {
      if (!activeProduct) return;
      const existing = cart.find(item => item.id === activeProduct.id);
      if (existing) { existing.qty += modalSelectedQty; }
      else { cart.push({ ...activeProduct, qty: modalSelectedQty }); }
      localStorage.setItem('awlad_issa_cart', JSON.stringify(cart));
      updateCartBadge();
      closeModal('userProductModal');
    }

    function updateCartBadge() {
      document.getElementById('cartCountBadge').innerText = cart.reduce((sum, item) => sum + item.qty, 0);
    }

    function renderCart() {
      const container = document.getElementById('cartItemsContainer');
      const totalDisplay = document.getElementById('cartTotalPrice');
      container.innerHTML = '';
      if (cart.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-muted); padding:20px 0;">السلة فارغة.</p>`;
        totalDisplay.innerText = "0.00 ج.م";
        return;
      }
      let grandTotal = 0;
      cart.forEach((item, index) => {
        const itemTotal = Number(item.price) * item.qty;
        grandTotal += itemTotal;
        container.innerHTML += `
          <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--card-border);">
            <div style="display:flex; align-items:center; gap:10px;">
              <img src="${item.image || 'https://via.placeholder.com/50'}" style="width:40px; height:40px; border-radius:8px; object-fit:cover;">
              <div>
                <b style="font-size:13px; display:block;">${item.name}</b>
                <span style="font-size:11px; color:var(--text-muted);">${item.price} ج.م × ${item.qty}</span>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:10px;">
              <b style="font-size:14px; color:var(--primary);">${itemTotal} ج.م</b>
              <button onclick="removeFromCart(${index})" style="background:#fee2e2; color:#ef4444; border:none; width:28px; height:28px; border-radius:6px; cursor:pointer;"><i class="fa-solid fa-trash"></i></button>
            </div>
          </div>
        `;
      });
      totalDisplay.innerText = `${grandTotal.toFixed(2)} ج.م`;
    }

    function removeFromCart(index) {
      cart.splice(index, 1);
      localStorage.setItem('awlad_issa_cart', JSON.stringify(cart));
      updateCartBadge();
      renderCart();
    }

    function loadUsersList() {
      const container = document.getElementById('usersListContainer');
      container.innerHTML = '';
      
      if (registeredUsers.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-muted); padding:15px 0;">لا توجد حسابات مسجلة.</p>`;
        return;
      }

      registeredUsers.forEach((user) => {
        let isMain = user.username === 'ali70';
        let actionBtn = '';
        
        if (isMain) {
          actionBtn = `<span style="font-size:11px; background:#dcfce7; color:#16a34a; padding:4px 8px; border-radius:6px; font-weight:bold;">المالك الأساسي</span>`;
        } else if (user.role === 'admin') {
          actionBtn = `<button onclick="toggleUserRole('${user.username}', 'user')" style="background:#fee2e2; color:#ef4444; border:none; padding:5px 10px; border-radius:6px; font-size:11px; font-weight:bold; cursor:pointer;">إزالة الأدمن</button>`;
        } else {
          actionBtn = `<button onclick="toggleUserRole('${user.username}', 'admin')" style="background:rgba(16,185,129,0.15); color:var(--primary); border:none; padding:5px 10px; border-radius:6px; font-size:11px; font-weight:bold; cursor:pointer;">ترقية لأدمن</button>`;
        }

        container.innerHTML += `
          <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--card-border);">
            <div>
              <b style="font-size:13px; display:block;">${user.username}</b>
              <span style="font-size:11px; color:var(--text-muted);">الدور: ${user.role === 'admin' ? 'مشرف (Admin)' : 'مستخدم عادي'}</span>
            </div>
            <div>${actionBtn}</div>
          </div>
        `;
      });
    }

    function toggleUserRole(username, newRole) {
      const targetUser = registeredUsers.find(u => u.username === username);
      if (targetUser) {
        targetUser.role = newRole;
        localStorage.setItem('awlad_issa_real_users', JSON.stringify(registeredUsers));
        db.collection('users').doc(targetUser.username).set(targetUser).catch(err => console.error('خطأ مزامنة الصلاحية:', err));

        if (currentUser && currentUser.username === username) {
          currentUser.role = newRole;
          localStorage.setItem('awlad_issa_session', JSON.stringify(currentUser));
          setupUserSession();
        }
        
        loadUsersList();
        alert(`تم تغيير صلاحية المستخدم ${username} إلى (${newRole === 'admin' ? 'أدمن' : 'مستخدم عادي'}) بنجاح!`);
      }
    }

    function saveProduct() {
      const id = document.getElementById('editProductId').value;
      const name = document.getElementById('pName').value;
      const price = document.getElementById('pPrice').value;
      const barcode = document.getElementById('pBarcode').value;
      const category = document.getElementById('pCategory').value;
      const image = document.getElementById('pImgUrl').value || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80';

      if (!name || !price) return;
      let savedProduct;
      if (id) {
        savedProduct = { id: Number(id), name, price, barcode, category, image };
        const idx = products.findIndex(p => p.id == id);
        if (idx !== -1) products[idx] = savedProduct;
      } else {
        savedProduct = { id: Date.now(), name, price, barcode, category, image };
        products.push(savedProduct);
      }
      localStorage.setItem('awlad_issa_products', JSON.stringify(products));
      db.collection('products').doc(String(savedProduct.id)).set(savedProduct).catch(err => console.error('خطأ مزامنة المنتج:', err));
      closeModal('addProductModal');
      showHome();
    }

    function triggerEditProductFromModal() {
      closeModal('userProductModal');
      document.getElementById('productModalTitle').innerText = "تعديل المنتج";
      document.getElementById('editProductId').value = activeProduct.id;
      document.getElementById('pName').value = activeProduct.name;
      document.getElementById('pPrice').value = activeProduct.price;
      document.getElementById('pBarcode').value = activeProduct.barcode || '';
      document.getElementById('pCategory').value = activeProduct.category;
      document.getElementById('pImgUrl').value = activeProduct.image;
      openModal('addProductModal');
    }

    function deleteProductFromModal() {
      const deletedId = activeProduct.id;
      products = products.filter(p => p.id !== deletedId);
      localStorage.setItem('awlad_issa_products', JSON.stringify(products));
      db.collection('products').doc(String(deletedId)).delete().catch(err => console.error('خطأ حذف المنتج:', err));
      closeModal('userProductModal');
      showHome();
    }

    function searchProducts() {
      const q = document.getElementById('searchInput').value.toLowerCase();
      if (!q) { showHome(); return; }
      document.getElementById('categoriesView').style.display = 'none';
      document.getElementById('productsView').style.display = 'block';
      document.getElementById('categoryTitle').innerText = "نتائج البحث";
      renderProductGrid(products.filter(p => p.name.toLowerCase().includes(q)));
    }

    // دوال الكاميرا والتصوير التلقائي المُعدلة
    function startScanner() {
      openModal('scannerModal');
      if (html5QrCode) {
        html5QrCode.stop().catch(() => {}).finally(() => {
          initializeScannerInstance();
        });
      } else {
        initializeScannerInstance();
      }
    }

    function initializeScannerInstance() {
      const containerId = "reader";
      document.getElementById(containerId).innerHTML = "";
      
      html5QrCode = new Html5Qrcode(containerId);
      const config = { fps: 10, qrbox: { width: 250, height: 250 } };
      
      html5QrCode.start(
        { facingMode: "environment" }, 
        config, 
        (decodedText) => {
          stopScanner();
          closeModal('scannerModal');
          document.getElementById('searchInput').value = decodedText;
          searchProducts();
        },
        (errorMessage) => {
          // تجاهل أخطاء الإطار المتكررة أثناء البحث عن الباركود
        }
      ).catch((err) => {
        console.error("فشل فتح الكاميرا:", err);
        alert("تعذر الوصول إلى الكاميرا، يرجى التأكد من منح الإذن.");
      });
    }

    function stopScanner() {
      if (html5QrCode) {
        html5QrCode.stop().then(() => {
          html5QrCode.clear();
          html5QrCode = null;
        }).catch((error) => {
          console.error("خطأ عند إيقاف الكاميرا:", error);
          html5QrCode = null;
        });
      }
    }

    function showHome() { document.getElementById('categoriesView').style.display = 'block'; document.getElementById('productsView').style.display = 'none'; }
    function openModal(id) { document.getElementById(id).classList.add('active'); }
    function closeModal(id) { document.getElementById(id).classList.remove('active'); }

    initApp();
